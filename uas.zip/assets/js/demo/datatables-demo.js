$(document).ready(function(){
  $('#dataTable').DataTable();
});

$(document).ready(function(){
  $('#kategori').DataTable();
});